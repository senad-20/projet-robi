package exercice4;

// 
//	(space setColor black)  
//	(robi setColor yellow) 
//	(space sleep 2000) 
//	(space setColor white)  
//	(space sleep 1000) 	
//	(robi setColor red)		  
//	(space sleep 1000)
//	(robi translate 100 0)
//	(space sleep 1000)
//	(robi translate 0 50)
//	(space sleep 1000)
//	(robi translate -100 0)
//	(space sleep 1000)
//	(robi translate 0 -40)
//

import java.awt.Dimension;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import graphicLayer.GRect;
import graphicLayer.GSpace;
import stree.parser.SNode;
import stree.parser.SParser;
import tools.Tools;

/**
 * Exercice 4.1 : interpréteur basé sur un environnement de références.
 *
 * Les objets manipulés sont enregistrés dans un Environment. Chaque Reference
 * connaît les commandes primitives qu'elle peut exécuter.
 */
public class Exercice4_1_0 {

	/** Environnement global des références accessibles par nom. */
	private Environment environment = new Environment();

	public Exercice4_1_0() {
		GSpace space = new GSpace("Exercice 4", new Dimension(200, 100));
		GRect robi = new GRect();

		space.addElement(robi);
		space.open();

		Reference spaceRef = new Reference(space);
		Reference robiRef = new Reference(robi);

		// Primitives comprises par space
		spaceRef.addCommand("setColor", new SetColor());
		spaceRef.addCommand("sleep", new Sleep());

		// Primitives comprises par robi
		robiRef.addCommand("setColor", new SetColor());
		robiRef.addCommand("translate", new Translate());

		// Enregistrement des références dans l'environnement
		environment.addReference("space", spaceRef);
		environment.addReference("robi", robiRef);

		this.mainLoop();
	}

	private void mainLoop() {
		while (true) {
			System.out.print("> ");
			String input = Tools.readKeyboard();

			SParser<SNode> parser = new SParser<>();
			List<SNode> compiled = null;

			try {
				compiled = parser.parse(input);
			} catch (IOException e) {
				e.printStackTrace();
				continue;
			}

			Iterator<SNode> itor = compiled.iterator();
			while (itor.hasNext()) {
				this.run(itor.next());
			}
		}
	}

	private void run(SNode expr) {
		String receiverName = expr.get(0).contents();
		Reference receiver = environment.getReferenceByName(receiverName);
		receiver.run(expr);
	}

	public static void main(String[] args) {
		new Exercice4_1_0();
	}
}