package exercice4;

import stree.parser.SNode;

/**
 * Interpréteur minimal : retrouve la référence cible puis exécute la commande.
 */
public class Interpreter {

	public Reference compute(Environment environment, SNode expr) {
		String receiverName = expr.get(0).contents();
		Reference receiver = environment.getReferenceByName(receiverName);
		return receiver.run(expr);
	}
}