package exercice4;

import graphicLayer.GBounded;
import graphicLayer.GElement;
import graphicLayer.GImage;

/**
 * Fabrique de références configurées pour les éléments graphiques.
 */
public final class GraphicReferenceFactory {

	private GraphicReferenceFactory() {
	}

	public static Reference createGraphicReference(GElement element) {
		Reference ref = new Reference(element);
		ref.addCommand("setColor", new SetColor());

		if (element instanceof GBounded) {
			ref.addCommand("translate", new Translate());
			ref.addCommand("setDim", new SetDim());
		}

		return ref;
	}

	public static Reference createImageReference(GImage image) {
		Reference ref = new Reference(image);
		ref.addCommand("translate", new ImageTranslate());
		return ref;
	}
}