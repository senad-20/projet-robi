package exercice4;

import java.util.HashMap;
import java.util.Map;

import stree.parser.SNode;

/**
 * Référence un objet Java et les commandes qu'il comprend.
 */
public class Reference {

	private Object receiver;
	private Map<String, Command> primitives;

	public Reference(Object receiver) {
		this.receiver = receiver;
		this.primitives = new HashMap<>();
	}

	public Object getReceiver() {
		return receiver;
	}

	public void addCommand(String name, Command command) {
		primitives.put(name, command);
	}

	public Reference run(SNode expr) {
		String commandName = expr.get(1).contents();
		Command command = primitives.get(commandName);

		if (command == null) {
			throw new Error("Commande inconnue : " + commandName + " pour " + receiver);
		}

		return command.run(this, expr);
	}
}