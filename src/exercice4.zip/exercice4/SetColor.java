package exercice4;

import java.awt.Color;

import graphicLayer.GElement;
import graphicLayer.GSpace;
import stree.parser.SNode;

/**
 * Primitive setColor pour space et les éléments graphiques.
 */
public class SetColor implements Command {

	@Override
	public Reference run(Reference receiver, SNode method) {
		String colorName = method.get(2).contents();
		Color color = parseColor(colorName);

		Object target = receiver.getReceiver();

		if (target instanceof GSpace) {
			((GSpace) target).setColor(color);
		} else if (target instanceof GElement) {
			((GElement) target).setColor(color);
		} else {
			throw new Error("setColor non supporté pour " + target.getClass().getName());
		}

		return receiver;
	}

	private Color parseColor(String name) {
		switch (name.toLowerCase()) {
		case "black":
			return Color.BLACK;
		case "white":
			return Color.WHITE;
		case "red":
			return Color.RED;
		case "yellow":
			return Color.YELLOW;
		case "blue":
			return Color.BLUE;
		case "green":
			return Color.GREEN;
		case "gray":
			return Color.GRAY;
		case "orange":
			return Color.ORANGE;
		case "pink":
			return Color.PINK;
		default:
			throw new Error("Couleur inconnue : " + name);
		}
	}
}