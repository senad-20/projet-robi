package exercice4;

import graphicLayer.GElement;
import stree.parser.SNode;

/**
 * Crée dynamiquement un élément graphique sans argument.
 *
 * Exemples :
 * (rect.class new)
 * (oval.class new)
 */
public class NewElement implements Command {

	@Override
	public Reference run(Reference receiver, SNode method) {
		try {
			@SuppressWarnings("unchecked")
			Class<? extends GElement> clazz = (Class<? extends GElement>) receiver.getReceiver();

			GElement element = clazz.getDeclaredConstructor().newInstance();
			return GraphicReferenceFactory.createGraphicReference(element);

		} catch (Exception e) {
			e.printStackTrace();
			throw new Error("Impossible de créer l'élément : " + method);
		}
	}
}