package exercice4;

import graphicLayer.GElement;
import graphicLayer.GSpace;
import stree.parser.SNode;

/**
 * Supprime un élément graphique du space et retire sa référence de
 * l'environnement.
 *
 * Exemple : (space del robi)
 */
public class DelElement implements Command {

	private Environment environment;

	public DelElement(Environment environment) {
		this.environment = environment;
	}

	@Override
	public Reference run(Reference receiver, SNode method) {
		String name = method.get(2).contents();

		Reference refToDelete = environment.getReferenceByName(name);
		Object container = receiver.getReceiver();
		Object element = refToDelete.getReceiver();

		if (!(container instanceof GSpace)) {
			throw new Error("del non supporté pour " + container.getClass().getName());
		}

		if (!(element instanceof GElement)) {
			throw new Error("L'objet à supprimer n'est pas un élément graphique");
		}

		((GSpace) container).removeElement((GElement) element);
		environment.removeReference(name);
		((GSpace) container).repaint();

		return receiver;
	}
}