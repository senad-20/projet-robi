package exercice4;

import graphicLayer.GElement;
import graphicLayer.GSpace;
import stree.parser.SNode;

/**
 * Ajoute dynamiquement un élément graphique dans le space et l'enregistre dans
 * l'environnement.
 *
 * Exemple : (space add robi (rect.class new))
 */
public class AddElement implements Command {

	private Environment environment;
	private Interpreter interpreter;

	public AddElement(Environment environment) {
		this.environment = environment;
		this.interpreter = new Interpreter();
	}

	@Override
	public Reference run(Reference receiver, SNode method) {
		String newName = method.get(2).contents();
		SNode creationExpr = method.get(3);

		Reference newReference = interpreter.compute(environment, creationExpr);

		Object container = receiver.getReceiver();
		Object element = newReference.getReceiver();

		if (!(container instanceof GSpace)) {
			throw new Error("add non supporté pour " + container.getClass().getName());
		}

		if (!(element instanceof GElement)) {
			throw new Error("L'objet créé n'est pas un élément graphique");
		}

		((GSpace) container).addElement((GElement) element);
		environment.addReference(newName, newReference);

		return newReference;
	}
}