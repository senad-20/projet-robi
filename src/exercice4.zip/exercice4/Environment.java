package exercice4;

import java.util.HashMap;
import java.util.Map;

/**
 * Environnement d'exécution.
 */
public class Environment {

	private Map<String, Reference> variables;

	public Environment() {
		this.variables = new HashMap<>();
	}

	public void addReference(String name, Reference reference) {
		variables.put(name, reference);
	}

	public Reference getReferenceByName(String name) {
		Reference ref = variables.get(name);

		if (ref == null) {
			throw new Error("Référence inconnue : " + name);
		}

		return ref;
	}

	public void removeReference(String name) {
		variables.remove(name);
	}
}